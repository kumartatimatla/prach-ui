const data = [
  { userName: "User1", review: "Great product!", iconSrc: "placeholder_1" },
  { userName: "User2", review: "Excellent service!", iconSrc: "placeholder_1" },
  {
    userName: "User3",
    review: "Highly recommended!",
    iconSrc: "placeholder_1",
  },
  { userName: "User4", review: "Superb quality!", iconSrc: "placeholder_1" },
  {
    userName: "User5",
    review: "Amazing experience! Highly recommended! Impressive features!",
    iconSrc: "placeholder_1",
  },
  { userName: "User6", review: "Top-notch support!", iconSrc: "placeholder_1" },
  {
    userName: "User7",
    review: "Impressive features!",
    iconSrc: "placeholder_1",
  },
  { userName: "User8", review: "Fast delivery!", iconSrc: "placeholder_1" },
  {
    userName: "User9",
    review: "Satisfied customer!Impressive features!",
    iconSrc: "placeholder_1",
  },
  {
    userName: "User10",
    review: "Efficient and reliable!",
    iconSrc: "placeholder_1",
  },
  //   {
  //     userName: "User11",
  //     review: "Great value for money! Impressive features!",
  //     iconSrc: "placeholder_1",
  //   },
  //   {
  //     userName: "User12",
  //     review: "Impressive features! Impressive features!",
  //     iconSrc: "placeholder_1",
  //   },
];

export const accoladesData = [...data];
